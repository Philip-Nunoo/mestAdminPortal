(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['particle4dev:sass'] = {};

})();

//# sourceMappingURL=particle4dev_sass.js.map
