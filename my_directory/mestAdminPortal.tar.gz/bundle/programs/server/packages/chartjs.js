(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var Chart;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package.chartjs = {
  Chart: Chart
};

})();

//# sourceMappingURL=chartjs.js.map
