(function(){__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var noLoginPageHookFunction, userHookFunction;

Router.configure({
  layoutTemplate: 'layoutTemplate',
  loadingTemplate: 'loadingTemplate',
  notFoundTemplate: 'notFoundTemplate',
  routeControllerNameConverter: "camelCase"
});

userHookFunction = function() {
  if (!Meteor.userId()) {
    return Router.go('sign-in');
  } else {
    return this.next();
  }
};

noLoginPageHookFunction = function() {
  if (Meteor.userId()) {
    return Router.go('dashboard');
  } else {
    return this.next();
  }
};

Router.onBeforeAction(noLoginPageHookFunction, {
  only: ['sign-in']
});

Router.onBeforeAction(userHookFunction, {
  only: ['dashboard', 'prospects', 'prospectsCategory', 'allApplicants', 'allEits', 'allAlumni', 'newApplicant', 'editEit', 'newEit', 'settings', 'editApplicant']
});

Router.route('/', function() {
  this.render('home');
}, {
  name: 'home'
});

Router.route('/sign-in', function() {
  this.render('signIn');
}, {
  name: 'sign-in'
});

Router.route('/dashboard', function() {
  this.render('dashboard');
  this.layout('dashboardLayout');
}, {
  name: 'dashboard'
});

Router.route('/user_settings', function() {
  this.render('userSettings');
  this.layout('dashboardLayout');
}, {
  name: 'userSettings'
});

Router.route('/records', function() {
  this.render('systemRecords');
  this.layout('dashboardLayout');
}, {
  name: 'records'
});

Router.route('/prospects', function() {
  this.render('prospects');
  this.layout('dashboardLayout');
}, {
  name: 'prospects',
  data: function() {
    return {
      prospects: Prospects.find().fetch(),
      eits: Prospects.find({
        category: 'eit'
      }).fetch(),
      fellows: Prospects.find({
        category: 'fellow'
      }).fetch(),
      staffs: Prospects.find({
        category: 'staff'
      }).fetch(),
      investors: Prospects.find({
        category: 'investor'
      }).fetch(),
      others: Prospects.find({
        category: 'others'
      }).fetch()
    };
  }
});

Router.route('/prospects/:category/', function() {
  this.layout('dashboardLayout');
  this.render('prospects');
}, {
  name: 'prospectsCategory',
  data: function() {
    return {
      prospects: Prospects.find({
        category: this.params.category
      }).fetch()
    };
  }
});

Router.route('/applicants', function() {
  this.render('applicants');
  this.layout('dashboardLayout');
}, {
  name: 'allApplicants'
});

Router.route('/all_eits', function() {
  this.render('allEits');
  return this.layout('dashboardLayout');
}, {
  name: 'allEits'
});

Router.route('/alumni', function() {
  this.render('alumni');
  this.layout('dashboardLayout');
}, {
  name: 'allAlumni'
});

Router.route('/new/eit', function() {
  this.render('newEit');
  this.layout('dashboardLayout');
}, {
  name: 'newEit'
});

Router.route('/new/applicant', function() {
  this.render('newApplicant');
  this.layout('dashboardLayout');
}, {
  name: 'newApplicant'
});

Router.route('/edit/applicant/:_id', function() {
  this.render('updateApplicant');
  this.layout('dashboardLayout');
}, {
  name: 'editApplicant',
  data: function() {
    var data, id;
    id = this.params._id;
    data = Applicants.findOne({
      _id: id
    });
    return {
      data: data
    };
  }
});

Router.route('/edit/eit/:_id', function() {
  this.render('updateEit');
  this.layout('dashboardLayout');
}, {
  name: 'editEit',
  data: function() {
    var data, id;
    id = this.params._id;
    data = Eits.findOne({
      _id: id
    });
    return {
      data: data
    };
  }
});

Router.route('/settings/:_id', function() {
  this.render('settings');
  this.layout('dashboardLayout');
}, {
  name: 'settings',
  data: function() {
    var data, id;
    id = this.params._id;
    if (id === 'newStage') {
      Session.set('settingsPage', 'nstage');
    }
    if (id === 'newSettings') {
      Session.set('settingsPage', 'nsettings');
    }
    if (id !== 'newStage' && id !== 'settings' && id !== 'newSettings') {
      data = Settings.findOne({
        _id: id
      });
      Session.set('settingsId', id);
      id = 'updateSettings';
    }
    return {
      template: id,
      dataContext: data
    };
  }
});

})();

//# sourceMappingURL=router.coffee.js.map
